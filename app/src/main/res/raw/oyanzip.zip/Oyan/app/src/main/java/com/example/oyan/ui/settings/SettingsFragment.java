package com.example.oyan.ui.settings;



import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;

import androidx.preference.Preference;

import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.PreferenceScreen;


import com.example.oyan.R;


public class SettingsFragment extends PreferenceFragmentCompat{



    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        addPreferencesFromResource(R.xml.timer_preferences);

        SharedPreferences sharedPreferences = getPreferenceScreen().getSharedPreferences();

        PreferenceScreen preferenceScreen = getPreferenceScreen();

        int count = preferenceScreen.getPreferenceCount();

        for(int i = 0; i < count; i++){
           Prefe


        }

    }


}