package com.example.oyan.ui.alarm.alarmlist;

import com.example.oyan.ui.alarm.data.Alarm;

public interface OnToggleAlarmListener {
    void onToggle(Alarm alarm);
}
